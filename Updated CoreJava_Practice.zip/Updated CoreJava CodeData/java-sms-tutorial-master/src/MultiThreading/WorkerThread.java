package MultiThreading;

public class WorkerThread implements Runnable{
	String massage;

	public WorkerThread(String massage) {
		super();
		this.massage = massage;
	}
	
	public void run(){
		System.out.println(Thread.currentThread().getName()+" (Start) Massage : "+massage);
		processThread();
		System.out.println(Thread.currentThread().getName()+" End of thread");
	}
	
	private void processThread(){
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
