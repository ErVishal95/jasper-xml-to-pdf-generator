package MultiThreading;

class ProducerConsumerProblem {
	int amount = 10000;

//WithDraw function
	synchronized void withdraw(int amt){
		System.out.println("Going to withdraw the amount "+amt);
		
		if(this.amount< amt){
			System.out.println("You are low on Bank Money "+amount);
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		this.amount-= amt;
		System.out.println("Amount withdrawn is : "+amt+" Remaining amount is : "+amount);
	}

//Deposit function
	protected int deposite(int amt){
		this.amount+= amt;
		
		return this.amount;
	}

//Execute method for notifying withdraw function for processing the withdrawl of amount
//This method will be executed only if the available amount is more or equal to withdraw amount
	synchronized void executeDeposite(int amt){
		System.out.println("Going to deposite amount via executeDeposit Method "+amt);
		//this.amount+= amt;
		
		System.out.println("Current Amount available "+amount);
		notify();
	}
}

