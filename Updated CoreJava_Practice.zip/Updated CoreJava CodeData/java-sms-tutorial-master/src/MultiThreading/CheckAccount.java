package MultiThreading;
class CheckAccount{
	static int w_amt= 15000;
	static int d_amt=5000;
	public static void main(String[] args) {
		final ProducerConsumerProblem pc= new ProducerConsumerProblem();
	
	//Thread code for executing the withdraw function with a validation via wait() method for checking the available balance
		new Thread(){
			public void run(){
				pc.withdraw(w_amt);
			}
		}.start();
		
	//Thread code for executing the deposit function after checking the available amount in user account
		new Thread(){
			public void run(){
			// condition for checking the whether available amt is more/equal to withdraw amt
				if(pc.amount<w_amt ){
					int amt_dif= pc.amount-w_amt;
					String amtdiff=String.valueOf(amt_dif).substring(1);
					System.out.println("Please deposit "+amtdiff+" amount more");
					
				}
			//condition for checking -whether available amt after deposited is more/equal to withdraw amt	
				int deposited_amt=pc.deposite(d_amt);
				String amtAfterDeposit= String.valueOf(deposited_amt-w_amt).substring(1);
				if(deposited_amt<w_amt){
					System.out.println("Going to deposite amount "+d_amt);
					System.out.println("Amount Deposited "+deposited_amt);
					System.out.println("Please deposit more amount "+amtAfterDeposit);
					
				}
				else
					pc.executeDeposite(d_amt);
				
			}
		}.start();
	}
}