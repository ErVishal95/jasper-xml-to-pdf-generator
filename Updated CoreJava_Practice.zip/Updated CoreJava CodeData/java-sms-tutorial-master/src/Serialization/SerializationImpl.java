package Serialization;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable; 

/*class CheckSerialization implements Serializable{
	int val1;
	String lastNama;
	transient int val2;
	static transient int val3;
}

class Test extends CheckSerialization{
	String firstName;
	private static final long serialVersionUID= 12L;
}
*/
class SerializationImpl{
	public static void main(String[] args) {
		Test test= new Test();
		test.firstName= "Vishal";
		test.lastNama= "Verma";
		test.val1= 12;
		test.val2= 23;
		test.val3= 44;
		
		try {
			FileOutputStream fout= new FileOutputStream("D://newfile.txt");
			ObjectOutputStream out = new ObjectOutputStream(fout);
			out.writeObject(test);
			out.close();
			out.flush();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(test.firstName+" "+test.lastNama+" "+test.val1+" "+test.val2+" "+test.val3);
		System.out.println("Data Executed Successfully");
	}
}
