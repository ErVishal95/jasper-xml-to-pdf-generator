package SortingInJava;

import java.util.*;

public class ReverseString {
	
	public static LinkedList<String> reverseString(String s){
		
		String[] str = null;
		for(int i=0; i<s.length()-1;i++){
			 str = s.split(" ");
		}
		
		LinkedList<String> ts= new LinkedList<String>(Arrays.asList(str));
		
		Collections.reverse(ts);
		
		//Collections.rotate(ts, 1);;
		
		/*
		LinkedList<String> al= new LinkedList<String>();
		Iterator<String> itr= ts.descendingIterator();
		while(itr.hasNext()){
			al.add(itr.next());
		}*/
		
		return ts;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s= sc.nextLine();
		
		LinkedList<String> str=reverseString(s);
		System.out.println(str);
		
		StringBuffer sb=new StringBuffer("Hello java");  
		sb.reverse();//now original string is changed  
		System.out.println(sb);
	}
}
