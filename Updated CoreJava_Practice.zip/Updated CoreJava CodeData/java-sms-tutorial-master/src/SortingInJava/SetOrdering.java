package SortingInJava;

import java.util.*;

public class SetOrdering {
	public static void main(String[] args) {
		TreeSet<String> sobj = new TreeSet<String>();
		//sobj.add(null); 
		sobj.add("Data");
		 sobj.add("Chacha");
		 sobj.add("Well");
		 sobj.add("Bhaisahib");
		 //Collections.sort(sobj, Collections.reverseOrder());;
		 System.out.println(sobj);
		 Iterator<String> itr=sobj.descendingIterator();
		 while(itr.hasNext()){
			 System.out.println(itr.next());
		 }
		 ArrayList<String> al = new ArrayList<String>();
		 al.addAll(sobj);
		 Collections.sort(al, Collections.reverseOrder());
		 System.out.println(al);
	}
}
