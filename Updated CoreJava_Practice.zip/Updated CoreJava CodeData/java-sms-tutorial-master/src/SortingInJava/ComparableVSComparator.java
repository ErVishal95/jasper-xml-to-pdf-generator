package SortingInJava;

import java.util.ArrayList;
import java.util.Collections;

class ComparableVSComparator{
	public static void main(String[] args) {
		ArrayList<ComparableVSComparatorExample> al= new ArrayList<ComparableVSComparatorExample>();
		al.add(new ComparableVSComparatorExample(12.01, "Vishal", 1998));
		al.add(new ComparableVSComparatorExample(22.11, "Jay", 1944));
		al.add(new ComparableVSComparatorExample(23.31, "Frank", 1912));
		al.add(new ComparableVSComparatorExample(1.12, "Zahir", 1991));
		
		Collections.sort(al);
		System.out.println("Collection after sorting");
		for(ComparableVSComparatorExample cvc: al){
			System.out.println(cvc.getYear()+" "+cvc.getRating()+" "+cvc.getName());
		}
		Collections.sort(al, new RatingComparator());
		System.out.println("Rating comparator implementation - Collection after sorting");
		for(ComparableVSComparatorExample cvc: al){
			System.out.println(cvc.getYear()+" "+cvc.getRating()+" "+cvc.getName());
		}
	}
}