package SortingInJava;

import java.util.Scanner;

public class BubleSort {
	//In Buble sort, sorting is done based on value of adjacent elements of an array 
	public static int[] bubleSort(int arr[]){
		int temp;
		int n= arr.length;
		for(int i=0; i<n; i++){
			for(int j=0; j<n-i-1; j++){
				if(arr[j]>arr[j+1]){
					temp= arr[j];
					arr[j]=arr[j+1];
					arr[j+1]= temp;
				}	
			}
		}
		return arr;
	}
	public static void printArray(int arr[]){
		for(int i=0; i<arr.length; i++){
			System.out.print(arr[i]+" ");
		}
	}
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int size=sc.nextInt();
		int arr[] = new int[size];
		for(int i=0; i<size; i++){
			arr[i] = sc.nextInt();
		}
		System.out.println("Printing the enterd array");
		printArray(arr);
		
		System.out.println("\n");
		//bubleSort(arr);
		System.out.println("Array after applying buble sort is: ");
		int[] sortedArray =bubleSort(arr);
		
		printArray(sortedArray);
	}

}
