package SortingInJava;

import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.TreeSet;

public class CheckSquarRoot {
	
	public static int sqrt(int z){
		int i=1, result=1;
		if(z==0 || z==1)
			System.out.println("Squar root can not be indentified");
		while(result <= z){
			i++;
			result= i*i;
			if(result== z)
				return i;
		}
		return 0;
	}
	public static void main(String[] args) {
	 //int x=12;
	 Scanner sc = new Scanner(System.in);
	 int z= sc.nextInt();
	 System.err.println(sqrt(z));
	 TreeSet<String> sobj = new TreeSet<String>();
	 sobj.add("Data");
	 sobj.add("Chacha");
	 sobj.add("Well");
	 sobj.add("Bhaisahib");
	 Collections.reverseOrder((Comparator<String>) sobj);
	 System.out.println(Collections.reverseOrder((Comparator<String>) sobj));
	}
}
