package SortingInJava;

import java.util.ArrayList;
import java.util.Collections;

class ComparableVSComparatorExample implements Comparable<ComparableVSComparatorExample>{
	
	private double rating;
	private String name;
	private int year;
	
	public int compareTo(ComparableVSComparatorExample cvc){
		//return this.name - cvc.name;
		return this.year - cvc.year;
	}

	public ComparableVSComparatorExample(double rating, String name, int year) {
		super();
		this.rating = rating;
		this.name = name;
		this.year = year;
	}

	public double getRating() {
		return rating;
	}
	public String getName() {
		return name;
	}
	public int getYear() {
		return year;
	}


}
