package SortingInJava;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

public class FreqOfMaxElement {

	public static void main(String[] args) {
	
		ArrayList<Integer> al = new ArrayList<Integer>(Arrays.asList(30,20,0,30,50,30,40,60)); 
      
        Collections.sort(al);
        System.out.println(al);
      
        Collections.sort(al, Collections.reverseOrder());
        System.out.println("After Reverse Method application: "+al);
        
        Collections.frequency(al, 10);
        System.out.println(Collections.frequency(al, 10));
        
        HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();
        for(Integer i: al){
      //  System.out.println(i+" "+Collections.frequency(al, i));
        hm.put(i, Collections.frequency(al, i));
        }
        int maxElement=-1, max=0;
        for(Map.Entry<Integer, Integer> hv : hm.entrySet()){
        	if(hv.getValue()>max){
        		max=hv.getValue();
        		maxElement=hv.getKey();
        	}
        }
        System.out.println(maxElement+" "+max);
        
//        System.out.println(Collections.reverseOrder((Comparator<String>) sobj));

	}
}
