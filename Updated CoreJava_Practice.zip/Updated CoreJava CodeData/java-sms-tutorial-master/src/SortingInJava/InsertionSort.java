package SortingInJava;

public class InsertionSort {
	//Method for performing Insertion Sort
	/*While dealing with insertion sort, the iteration starts from 1st index instead of 0th
	 * With in the outer for loop scope the very first element value is stored in another variable
	 * and i-1 is assigned to j(the initialization condition for inner while loop)*/
	public static int[] insertionSort(int arr[]){
		int n= arr.length;
		for(int i=1; i<n; i++){
			int unitvalue= arr[i];
			int j=i-1;
			while(j>=0 && arr[j]> unitvalue){  	//while loop condition to check whether value of arr[j] is greater then value of arr[i]
				arr[j+1]=arr[j];				//as the condition becomes true value at arr[j] gets assigned to arr[j+1]
				j=j-1;							//iteration - decreasing j by 1
			}
			arr[j+1]= unitvalue;				// As after value of j becomes -1 and loop execution completes, the value of arr[i] 
		}										//i.e., value gets assigned to the index which is 1 index greater then the index holding
		for(int i=0;i<n;i++){					//elements smaller then the unitvalue.
			System.out.println(arr[i]+" ");
		}
		return arr;
	}
	public static void main(String[] args) {
		int arr[]={11,2,5,89,6};
		insertionSort(arr);
	}
}
