package SortingInJava;

import java.math.BigInteger;

public class DataTypeFormat {
	static int a= 2147222222;
	static byte b= 127;
	static short s= 32767;
	static long l= 9222999999999999999L;
	static float f= 998.365124f;		//total digits can be upto count of 7 in case of float value
	
	static double d= 9989999.3651244523d;		//total digits can be upto count of 7 in case of 
	
	static BigInteger bigInt= new BigInteger("99999999999999999999999999999999");
	public static void main(String[] args) {
		System.out.println(a);
		System.out.println(bigInt);
		System.out.println(bigInt.add(new BigInteger("99999999999999999999999999999914545555487987979787978")));
		System.out.println(bigInt.multiply(new BigInteger("99999999999999999999999999999914545555487987979787978")));
		System.out.println(bigInt.divide(new BigInteger("85")));
		System.out.println(f);
		System.out.println(d);
	}
}
