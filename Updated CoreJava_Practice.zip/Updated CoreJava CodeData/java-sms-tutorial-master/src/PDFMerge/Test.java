package PDFMerge;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;

public class Test {
	
	 final static File RESULT_FOLDER = new File("C:\\Users\\vishal.verma\\Desktop\\SAMBA\\RESULT_FOLDER");
	 /*public static void testMergeOnlyGraphics() throws DocumentException, IOException
	    {
	        byte[] docA = createSimpleCircleGraphicsPdf(20, 20, 20);
	        Files.write(new File(RESULT_FOLDER, "Test1.pdf").toPath(), docA);
	        byte[] docB = createSimpleCircleGraphicsPdf(50, 10, 2);
	        Files.write(new File(RESULT_FOLDER, "Test2.pdf").toPath(), docB);
	        byte[] docC = createSimpleCircleGraphicsPdf(100, -20, 3);
	        Files.write(new File(RESULT_FOLDER, "Test3.pdf").toPath(), docC);
	        byte[] docD = createSimpleCircleGraphicsPdf(20, 20, 20);
	        Files.write(new File(RESULT_FOLDER, "circlesOnlyD.pdf").toPath(), docD);

	        PdfVeryDenseMergeTool tool = new PdfVeryDenseMergeTool(PageSize.A4, 18, 18, 5);
	        PdfReader readerA = new PdfReader(docA);
	        PdfReader readerB = new PdfReader(docB);
	        PdfReader readerC = new PdfReader(docC);
	      //  PdfReader readerD = new PdfReader(docD);
	        try (FileOutputStream fos = new FileOutputStream(new File(RESULT_FOLDER, "Test4.pdf")))
	        {
	            List<PdfReader> inputs = Arrays.asList(readerA, readerB, readerC);
	            tool.merge(fos, inputs);
	        }
	        finally
	        {
	            readerA.close();
	            readerB.close();
	            readerC.close();
	          //  readerD.close();
	        }
	    }*/
	 
	 public static void testMergeOnlyText() throws DocumentException, IOException
	    {
	        byte[] docA = createByteArrayOfPDFData("C:\\Users\\vishal.verma\\Desktop\\SAMBA\\RESULT_FOLDER\\Test1.pdf");//createSimpleTextPdf("First document, paragraph %s.", 3);
	       // Files.write(new File(RESULT_FOLDER, "Test1.pdf").toPath(), docA);
	        byte[] docB = createByteArrayOfPDFData("C:\\Users\\vishal.verma\\Desktop\\SAMBA\\RESULT_FOLDER\\Test2.pdf"); //createSimpleTextPdf("Second document, paragraph %s.", 3);
	      //  Files.write(new File(RESULT_FOLDER, "Test2.pdf").toPath(), docB);
	        //byte[] docC = createByteArrayOfPDFData("C:\\Users\\vishal.verma\\Desktop\\SAMBA\\RESULT_FOLDER\\Test3.pdf");  //createSimpleTextPdf("Third document, paragraph %s, a bit longer lines.", 3);
	      //  Files.write(new File(RESULT_FOLDER, "Test3.pdf").toPath(), docC);
	      /*  byte[] docD = createSimpleTextPdf("Fourth document, paragraph %s, let us make this a much longer paragraph spanning more than one line.", 3);
	        Files.write(new File(RESULT_FOLDER, "Test1.pdf").toPath(), docD);
*/
	        PdfVeryDenseMergeTool tool = new PdfVeryDenseMergeTool(PageSize.A4, 18, 1, 5);
	        PdfReader readerA = new PdfReader(docA);
	        PdfReader readerB = new PdfReader(docB);
	       // PdfReader readerC = new PdfReader(docC);
	        //PdfReader readerD = new PdfReader(docD);
	        try (FileOutputStream fos = new FileOutputStream(new File(RESULT_FOLDER, "textOnlyMerge-veryDense.pdf")))
	        {
	            //List<PdfReader> inputs = Arrays.asList(readerA, readerB, readerC);
	        	List<PdfReader> inputs = Arrays.asList(readerA, readerB);
	        	tool.merge(fos, inputs);
	        }
	        finally
	        {
	            readerA.close();
	            readerB.close();
	          //  readerC.close();
	           // readerD.close();
	        }
	    }
	    
	    static byte[] createSimpleTextPdf(String paragraphFormat, int paragraphCount) throws DocumentException
	    {
	        ByteArrayOutputStream baos = new ByteArrayOutputStream();

	        Document document = new Document();
	        PdfWriter.getInstance(document, baos);
	        document.open();
	        for (int i = 0; i < paragraphCount; i++)
	        {
	            Paragraph paragraph = new Paragraph();
	            paragraph.add(String.format(paragraphFormat, i));
	            document.add(paragraph);
	        }
	        document.close();

	        return baos.toByteArray();
	    }
	    
	    static byte[] createByteArrayOfPDFData(String str) throws IOException{
	    	File file = new File(str); 
	        FileInputStream fis = new FileInputStream(file);
	    	 ByteArrayOutputStream bos = new ByteArrayOutputStream();
	         byte[] buf = new byte[1024];
	         try {
	             for (int readNum; (readNum = fis.read(buf)) != -1;) {
	         
	         
	             		bos.write(buf, 0, readNum); //no doubt here is 0
	                     //Writes len bytes from the specified byte array starting at offset off to this byte array output stream.
	                     System.out.println("read " + readNum + " bytes,");
	             	}
	             		
	             
	         } catch (IOException ex) {
	         
	         }
	         byte[] bytes = bos.toByteArray();
	         
	         
	       fis.close(); 
	       bos.close();
	         return bytes;
	    }
	   /* static byte[] createSimpleCircleGraphicsPdf(int radius, int gap, int count) throws DocumentException
	    {
	        ByteArrayOutputStream baos = new ByteArrayOutputStream();

	        Document document = new Document();
	        PdfWriter writer = PdfWriter.getInstance(document, baos);
	        document.open();

	        float y = writer.getPageSize().getTop();
	        for (int i = 0; i < count; i++)
	        {
	            Rectangle pageSize = writer.getPageSize();
	            if (y <= pageSize.getBottom() + 2*radius)
	            {
	                y = pageSize.getTop();
	                writer.getDirectContent().fillStroke();
	                document.newPage();
	            }
	            writer.getDirectContent().circle(pageSize.getLeft() + pageSize.getWidth() * Math.random(), y-radius, radius);
	            y-= 2*radius + gap;
	        }
	        writer.getDirectContent().fillStroke();
	        document.close();

	        return baos.toByteArray();
	    }*/
	
	public static void main(String[] args) throws DocumentException, IOException {
		// TODO Auto-generated method stub
		//testMergeOnlyGraphics();
		testMergeOnlyText();
		
		System.out.println("Success");
	}

}
