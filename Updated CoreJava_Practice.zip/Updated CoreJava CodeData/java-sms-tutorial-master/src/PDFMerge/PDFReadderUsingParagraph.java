package PDFMerge;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;



public class PDFReadderUsingParagraph {
	
	/*private static String getParagraphs(String filePath, int linecount) throws IOException {
	    Paragraph paragraphDetector = new Paragraph();
	    StringBuilder extracted = new StringBuilder();
	    LineSeparator it = IOUtils.lineIterator(new BufferedReader(new FileReader(filePath)));
	    int i = 0;
	    String line;
	        for (int lineNumber = 0; it.hasNext(); lineNumber++) {
	            line = (String) it.next();
	            if (lineNumber == linecount) {
	                for (int j = 0; it.hasNext(); j++) {
	                    extracted.append((String) it.next());
	                }
	            }
	        }
	        return paragraphDetector.SentenceSplitter(extracted.toString());
	    }*/
	
	public static void main(String args[]) throws InvalidPasswordException, IOException, DocumentException {
		 File file = new File("C:/Users/vishal.verma/Desktop/SAMBA/Samba DEMO/New folder/New folder/myhtmlreport (41).pdf");
		    PDDocument document = PDDocument.load(file);        
		    PDFTextStripper pdfStripper = new PDFTextStripper();
		    pdfStripper.getSpacingTolerance();
		    pdfStripper.setParagraphStart("/t");
		    pdfStripper.setSortByPosition(true);

		    Document doc =new Document();
		    
	         PdfWriter writer = PdfWriter.getInstance(doc, new FileOutputStream("C:/Users/vishal.verma/Desktop/SAMBA/datacheck.pdf"));
	         doc.open();
		    
		    for (String line: pdfStripper.getText(document).split(pdfStripper.getParagraphStart()))
		            {
		    	         if(!line.isEmpty() && !line.contains("1")){
		               
		    	        	 doc.add(new Paragraph(line));
		    		        	 
		    	        System.out.println(line);
		                System.out.println("********************************************************************");
		    	         }
		            }
		    
		    doc.close();
	         writer.close();
		    
		   
	        
	
		}	
}

