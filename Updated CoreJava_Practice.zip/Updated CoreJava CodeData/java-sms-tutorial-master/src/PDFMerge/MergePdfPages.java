package PDFMerge;

import org.apache.pdfbox.multipdf.PDFMergerUtility; 
import org.apache.pdfbox.pdmodel.PDDocument;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfArray;
import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.parser.PdfReaderContentParser;
import com.itextpdf.text.pdf.parser.TextMarginFinder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;  

public class MergePdfPages { 
   public static void main(String[] args) throws IOException, DocumentException { 
      
      //Loading an existing PDF document 
    /*  File file1 = new File("C:/Users/vishal.verma/Desktop/SAMBA/Samba DEMO/New folder/New folder/myhtmlreport (41).pdf"); 
      PDDocument doc1 = PDDocument.load(file1); */

      //+++++++++++++++++
      
      PdfReader reader = new PdfReader("C:\\Users\\vishal.verma\\Desktop\\SAMBA\\merged.pdf"); 
      PdfStamper stamper = new PdfStamper(reader, new FileOutputStream("C:/Users/vishal.verma/Desktop/SAMBA/test-trimmed-stamper.pdf")); 

      // Go through all pages 
      
      int n = reader.getNumberOfPages(); 
      for (int i = 1; i <= n; i++) 
      { 
    	 // Document doc = new Document(PageSize.A4.rotate(), 60, 30, 30, 30);
          Rectangle pageSize = reader.getPageSize(i); 
          Rectangle rect = getOutputPageSize(pageSize, reader, i); 
        
          
          PdfDictionary page = reader.getPageN(i); 
          page.put(PdfName.CROPBOX, new PdfArray(new float[]{rect.getLeft(), rect.getBottom(), rect.getRight(), rect.getTop()})); 
          stamper.markUsed(page); 
      } 
      stamper.close(); 
      System.out.println("success");
      
      //+++++++++++++++++++++
      
     /* 
      File file2 = new File("C:/Users/vishal.verma/Desktop/SAMBA/Samba DEMO/New folder/New folder/myhtmlreport (41).pdf"); 
      PDDocument doc2 = PDDocument.load(file2); 

      //Instantiating PDFMergerUtility class 
      PDFMergerUtility PDFmerger = new PDFMergerUtility();       

      //Setting the destination file 
      PDFmerger.setDestinationFileName("C:/Users/vishal.verma/Desktop/SAMBA/merged.pdf"); 

      //adding the source files 
      PDFmerger.addSource(file1); 
      PDFmerger.addSource(file2); 

      //Merging the two documents 
      PDFmerger.mergeDocuments(); 
      System.out.println("Documents merged"); 

      //Closing the documents 
      doc1.close(); 
      doc2.close(); */   
      
      
   }

   private static Rectangle getOutputPageSize(Rectangle pageSize, PdfReader reader, int page) throws IOException 
   { 
	   
       PdfReaderContentParser parser = new PdfReaderContentParser(reader);
       TextMarginFinder finder = parser.processContent(page, new TextMarginFinder());
       Rectangle result = new Rectangle(finder.getLlx(), finder.getLly(), finder.getUrx(), finder.getUry());
       
       //Rectangle result = new Rectangle(30, 30, 550, 800);
       System.out.printf("Text/bitmap boundary: %f,%f to %f, %f\n", finder.getLlx(), finder.getLly(), finder.getUrx(), finder.getUry());
       return result;
   }
}
