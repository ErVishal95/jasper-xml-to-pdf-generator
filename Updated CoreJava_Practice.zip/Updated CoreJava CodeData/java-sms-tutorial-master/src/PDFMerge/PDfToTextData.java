package PDFMerge;

import java.io.FileOutputStream;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

public class PDfToTextData {
	public static void main(String[] args) {
		try {   
			
			// Text String Extractor
			
		    PdfReader reader = new PdfReader("C:/Users/vishal.verma/Desktop/SAMBA/Samba DEMO/New folder/New folder/myhtmlreport (41).pdf");
		    int n = reader.getNumberOfPages(); 
		    String str=PdfTextExtractor.getTextFromPage(reader, 1); //Extracting the content from a particular page.
		    System.out.println(str+"     newgen");
		    reader.close();
		    
		 // Text to PDF Generator
			
		    
		    Document doc =new Document();
		    
		         PdfWriter writer = PdfWriter.getInstance(doc, new FileOutputStream("C:/Users/vishal.verma/Desktop/SAMBA/datacheck.pdf"));
		         doc.open();
		         doc.add(new Paragraph(str));
		         doc.close();
		         writer.close();
		    
		} catch (Exception e) {
		    System.out.println(e);
		}
		
	
	}
}
