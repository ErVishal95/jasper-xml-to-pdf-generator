package Merging;



import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;

public class Test {
	
	 final static File RESULT_FOLDER = new File("C:\\Users\\vishal.verma\\Desktop\\SAMBA\\RESULT_FOLDER");
	
	 
	 public static void testMergeOnlyText() throws DocumentException, IOException
	    {
	        byte[] docA = createByteArrayOfPDFData("C:\\Users\\vishal.verma\\Desktop\\SAMBA\\RESULT_FOLDER\\page1.pdf");//createSimpleTextPdf("First document, paragraph %s.", 3);
	       // Files.write(new File(RESULT_FOLDER, "Test1.pdf").toPath(), docA);
	        byte[] docB = createByteArrayOfPDFData("C:\\Users\\vishal.verma\\Desktop\\SAMBA\\RESULT_FOLDER\\Page2.pdf"); //createSimpleTextPdf("Second document, paragraph %s.", 3);
	      //  Files.write(new File(RESULT_FOLDER, "Test2.pdf").toPath(), docB);
	        byte[] docC = createByteArrayOfPDFData("C:\\Users\\vishal.verma\\Desktop\\SAMBA\\RESULT_FOLDER\\page3.pdf");  //createSimpleTextPdf("Third document, paragraph %s, a bit longer lines.", 3);
	      //  Files.write(new File(RESULT_FOLDER, "Test3.pdf").toPath(), docC);
	      /*  byte[] docD = createSimpleTextPdf("Fourth document, paragraph %s, let us make this a much longer paragraph spanning more than one line.", 3);
	        Files.write(new File(RESULT_FOLDER, "Test1.pdf").toPath(), docD);
*/
	        //PdfVeryDenseMergeTool tool = new PdfVeryDenseMergeTool(PageSize.A4, 18, 1, 5);
	        
	        PdfVeryDenseMergeTool tool = new PdfVeryDenseMergeTool(PageSize.A4, 45, 45, 0);
	        PdfReader readerA = new PdfReader(docA);
	        PdfReader readerB = new PdfReader(docB);
	        PdfReader readerC = new PdfReader(docC);
	        //PdfReader readerD = new PdfReader(docD);
	        try (FileOutputStream fos = new FileOutputStream(new File(RESULT_FOLDER, "Output.pdf")))
	        {
	           List<PdfReader> inputs = Arrays.asList(readerA, readerB, readerC);
	        	//List<PdfReader> inputs = Arrays.asList(readerA, readerB);
	        	tool.merge(fos, inputs);
	        	
	        }
	        finally
	        {
	            readerA.close();
	            readerB.close();
	            readerC.close();
	           // readerD.close();
	        }
	    }
	    
	    static byte[] createSimpleTextPdf(String paragraphFormat, int paragraphCount) throws DocumentException
	    {
	        ByteArrayOutputStream baos = new ByteArrayOutputStream();

	        Document document = new Document();
	        PdfWriter.getInstance(document, baos);
	        document.open();
	        for (int i = 0; i < paragraphCount; i++)
	        {
	            Paragraph paragraph = new Paragraph();
	            paragraph.add(String.format(paragraphFormat, i));
	            document.add(paragraph);
	        }
	        document.close();

	        return baos.toByteArray();
	    }
	    
	    static byte[] createByteArrayOfPDFData(String str) throws IOException{
	    	File file = new File(str); 
	        FileInputStream fis = new FileInputStream(file);
	    	 ByteArrayOutputStream bos = new ByteArrayOutputStream();
	         byte[] buf = new byte[1024];
	         try {
	             for (int readNum; (readNum = fis.read(buf)) != -1;) {
	         
	         
	             		bos.write(buf, 0, readNum); //no doubt here is 0
	                     //Writes len bytes from the specified byte array starting at offset off to this byte array output stream.
	                     System.out.println("read " + readNum + " bytes,");
	             	}
	             		
	             
	         } catch (IOException ex) {
	         
	         }
	         byte[] bytes = bos.toByteArray();
	         
	         
	       fis.close(); 
	       bos.close();
	         return bytes;
	    }
	  
	
	public static void main(String[] args) throws DocumentException, IOException {
		System.out.println("start  "+System.currentTimeMillis());
		testMergeOnlyText();
		System.out.println("end   "+System.currentTimeMillis());
		System.out.println("Success");
		
		
		 try {
			 PdfReader reader = new PdfReader("C:\\Users\\vishal.verma\\Desktop\\SAMBA\\RESULT_FOLDER\\Output.pdf");

			 PdfStamper stamper = new PdfStamper(reader,
			          new FileOutputStream("C:\\Users\\vishal.verma\\Desktop\\SAMBA\\modified.pdf")); // output PDF
			        BaseFont bf = BaseFont.createFont(
			                BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED); // set font
			        
			       
			        //loop on pages (1-based)
			        for (int i=1; i<=reader.getNumberOfPages(); i++){

			            // get object for writing over the existing content;
			            // you can also use getUnderContent for writing in the bottom layer
			            if(i==1){
			            	PdfContentByte over = stamper.getOverContent(i);
			            	
			            	String s1= "Tokio Marine HCC is a trading name of HCC International Insurance Company plc, which is a member of the Tokio Marine HCC Group of";
				            String s2= "Companies. HCC International Insurance Company plc is authorised by the Prudential Regulation Authority (PRA) and regulated by the UK";
				            String s3= "Financial Conduct Authority (FCA) and Prudential Regulation Authority. Registered in England and Wales No. 01575839 with registered office at 1";
				            String s4= "Aldgate, London EC3N 1RE.";
				            // write text
				            over.beginText();
				            over.setFontAndSize(bf, 7);    // set font and size
				            over.setTextMatrix(40, 35);   // set x,y position (0,0 is at the bottom left)
				            over.showText(s1); 
				            //over.showTextAligned(22, s, 5.0f, 10.0f, 0.0f);// set text
				            over.endText();
				            over.beginText();
				            over.setFontAndSize(bf, 7);    // set font and size
				            over.setTextMatrix(40, 25);   // set x,y position (0,0 is at the bottom left)
				            over.showText(s2); 
				            //over.showTextAligned(22, s, 5.0f, 10.0f, 0.0f);// set text
				            over.endText();
				            over.beginText();
				            over.setFontAndSize(bf, 7);    // set font and size
				            over.setTextMatrix(40, 15);   // set x,y position (0,0 is at the bottom left)
				            over.showText(s3); 
				            //over.showTextAligned(22, s, 5.0f, 10.0f, 0.0f);// set text
				            over.endText();
				            over.beginText();
				            over.setFontAndSize(bf, 7);    // set font and size
				            over.setTextMatrix(40, 5);   // set x,y position (0,0 is at the bottom left)
				            over.showText(s4); 
				            //over.showTextAligned(22, s, 5.0f, 10.0f, 0.0f);// set text
				            over.endText();
			            }
			            else{
			            	PdfContentByte over = stamper.getOverContent(i);

				            // write text
				            over.beginText();
				            over.setFontAndSize(bf, 10);    // set font and size
				            over.setTextMatrix(325, 10);   // set x,y position (0,0 is at the bottom left)
				            String s= "Professional Risks | PMR Monthly Quotation 0317 | ";
				            over.showText(s+ (i-1)); 
				            //over.showTextAligned(22, s, 5.0f, 10.0f, 0.0f);// set text
				            over.endText();
			            }

			           
			        }
			        System.out.println("Data written");
			        stamper.close();
			 
		} finally {
			// TODO: handle finally clause
		}
		
	/*	PdfReader reader = new PdfReader("C:\\Users\\vishal.verma\\Desktop\\SAMBA\\RESULT_FOLDER\\Output.pdf");
		
		Document document = new Document();
		PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("C:\\Users\\vishal.verma\\Desktop\\SAMBA\\HeaderFooter.pdf"));
	        Rectangle rect = new Rectangle(30, 30, 550, 800);
	        writer.setBoxSize("art", rect);
	        HeaderFooterPageEvent event = new HeaderFooterPageEvent();
	        writer.setPageEvent(event);
	        document.open();
	     //   document.add(new Paragraph("This is Page One"));
	     //   document.newPage();
	    //    document.add(new Paragraph("This is Page two"));
	        document.close();
		System.out.println("Done");*/
		
	}

}

